<?php

namespace App\Http\Controllers;
use App\Models\News;
use App\Models\Comment;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class Newsmanagement extends Controller
{
    //
    public function index(){
        $News = News::get();
        $Comment = Comment::get();

        return view('news',['News'=>$News, 'Comment'=>$Comment]);
    }
}
